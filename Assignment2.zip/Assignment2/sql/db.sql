CREATE TABLE newStaff (
    id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fname varchar(100) NOT NULL,
	age varchar(100) NOT NULL,
    email varchar(100) NOT NULL

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;