<?php

class database{
  private $servername = "172.31.22.43";
  private $username   = "Rahul200514873";
  private $password   = "G3MPwhtGQW";
  private $database   = "Rahul200514873";
  public  $con;


  public function __construct()
  {
    $this->con = new mysqli($this->servername, $this->username,$this->password,$this->database);
    if(mysqli_connect_error()) {
      trigger_error("Failed to connect to MySQL: " . mysqli_connect_error());
    }else{
      return $this->con;
    }
  }

  // Inserting dadta to server
  public function addData($post)
  {
    $name = $this->con->real_escape_string($_POST['name']);
    $email = $this->con->real_escape_string($_POST['email']);
    $age = $this->con->real_escape_string($_POST['age']);
    $query="INSERT INTO newStaff(fname,email,age) VALUES('$name','$email','$age')";
    $sql = $this->con->query($query);
    if ($sql==true) {
      header("Location:fill.php?msg1=insert");
    }else{
      echo "Registration failed!";
    }
  }

  // Show registered mail, name and age
  public function showValue()
  {
    $query = "SELECT * FROM newStaff";
    $result = $this->con->query($query);
    if ($result->num_rows > 0) {
      $data = array();
      while ($row = $result->fetch_assoc()) {
        $data[] = $row;
      }
      return $data;
    }
  }


}
